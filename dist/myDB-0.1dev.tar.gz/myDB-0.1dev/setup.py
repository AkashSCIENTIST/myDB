from distutils.core import setup

setup(
   name='myDB', 
   version='0.1dev',
   packages=['myDB',],
   license='MIT', 
   long_description=open('README.md').read(),
)